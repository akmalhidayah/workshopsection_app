<?php

namespace App\View\Components;

use Illuminate\View\Component;

class PkmLayout extends Component
{
    public function render()
    {
        return view('layouts.pkm-layout');
    }
}
