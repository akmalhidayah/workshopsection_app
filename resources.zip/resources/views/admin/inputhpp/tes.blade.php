<td class="px-2 py-2">
                                    @if(!$notification->hpp1)
                                        <span class="text-gray-500">HPP Belum dibuat</span>
                                    @elseif(!$notification->hpp1->manager_signature)
                                        <span class="text-red-500">Menunggu Tanda Tangan Manager Pengendali</span>
                                    @elseif(!$notification->hpp1->senior_manager_signature)
                                        <span class="text-red-500">Menunggu Tanda Tangan Senior Manager Pengendali</span>
                                    @elseif(!$notification->hpp1->manager_signature_requesting_unit)
                                        <span class="text-red-500">Menunggu Tanda Tangan Manager Peminta</span>
                                    @elseif(!$notification->hpp1->senior_manager_signature_requesting_unit)
                                        <span class="text-red-500">Menunggu Tanda Tangan Senior Manager Peminta</span>
                                    @elseif(!$notification->hpp1->general_manager_signature)
                                        <span class="text-red-500">Menunggu Tanda Tangan General Manager Pengendali</span>
                                    @elseif(!$notification->hpp1->general_manager_signature_requesting_unit)
                                        <span class="text-red-500">Menunggu Tanda Tangan General Manager Peminta</span>
                                    @else
                                        <span class="text-green-500">Telah Ditandatangani</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4 border-b border-gray-200 text-sm">
                                    @if ($data->source_form === 'createhpp1')
                                        @if (is_null($data->manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Manager Bengkel Mesin</span>
                                        @elseif (is_null($data->senior_manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Senior Manager Workshop</span>
                                        @elseif (is_null($data->manager_signature_requesting_unit))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Manager Peminta</span>
                                        @elseif (is_null($data->senior_manager_signature_requesting_unit))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Senior Manager Peminta</span>
                                        @elseif (is_null($data->general_manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari General Manager Pengendali</span>
                                        @elseif (is_null($data->general_manager_signature_requesting_unit))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari General Manager Peminta</span>
                                        @elseif (is_null($data->director_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Director</span>
                                        @else
                                            <span class="text-green-500">Telah di Tanda Tangani</span>
                                        @endif

                                    @elseif ($data->source_form === 'createhpp2')
                                        @if (is_null($data->manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Manager Bengkel Mesin</span>
                                        @elseif (is_null($data->senior_manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Senior Manager Workshop</span>
                                        @elseif (is_null($data->manager_signature_requesting_unit))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Manager Peminta</span>
                                        @elseif (is_null($data->senior_manager_signature_requesting_unit))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Senior Manager Peminta</span>
                                        @elseif (is_null($data->general_manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari General Manager</span>
                                        @elseif (is_null($data->general_manager_signature_requesting_unit))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari General Manager Peminta</span>
                                        @else
                                            <span class="text-green-500">Telah di Tanda Tangani</span>
                                        @endif

                                    @elseif ($data->source_form === 'createhpp3')
                                        @if (is_null($data->manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Manager Bengkel Mesin</span>
                                        @elseif (is_null($data->senior_manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari Senior Manager Workshop</span>
                                        @elseif (is_null($data->general_manager_signature))
                                            <span class="text-red-500">Menunggu Tanda Tangan dari General Manager</span>
                                        @else
                                            <span class="text-green-500">Telah di Tanda Tangani</span>
                                        @endif

                                    @else
                                        <span class="text-gray-500">Source Form Tidak Diketahui</span>
                                    @endif
                                </td>